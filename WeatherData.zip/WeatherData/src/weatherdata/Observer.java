package weatherdata;

public interface Observer{
  public void update(float a, float b, float c);

}
