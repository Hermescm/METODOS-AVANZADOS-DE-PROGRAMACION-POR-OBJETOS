package pkg180124_practica;


import pkg180124_practica.Character;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hermes
 */
public class Knight extends Character{
    
    @Override
    public void fight(){
        
        System.out.println("Peleando estilo Caballero");
        
        this.weapon.useWeapon();
       
    }
    
    
}
