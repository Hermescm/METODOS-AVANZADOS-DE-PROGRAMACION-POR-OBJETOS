package pkg180124_practica;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hermes
 */
public abstract class Character {
    WeaponBehavior weapon;
    
    public Character(){
        this.weapon = new KnifeBehavior();
    }
    
    public abstract void fight();
    
    public void setWeapon(WeaponBehavior weapon){
        
        this.weapon = weapon;
    
        
    }
}
