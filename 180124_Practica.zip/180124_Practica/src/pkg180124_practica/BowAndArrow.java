/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg180124_practica;

/**
 *
 * @author Hermes
 */
public class BowAndArrow implements WeaponBehavior {
    @Override
    public void useWeapon(){
        System.out.println("Atacando usando Arco y Flecha");
    }
}
