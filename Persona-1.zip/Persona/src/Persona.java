interface Motriz
{
    public void moverse();
    public void respirar();
    public void caminar();
    public void hablar();

}
interface ManosMov extends Motriz{
    public void moverManos();
}

public class Persona implements Motriz
{
    
    String Nombre;
    int Edad;
    
   
   public void respirar()
   {
	System.out.println("Respirando");
   }
   
   public void caminar()
   {
	System.out.println("Caminando");
   }
   
   public void moverse()
   {
	System.out.println("Moviendose");
   }
   
   public void hablar()
   {
	System.out.println("Hablando");
   }
   
   public static void main(String arg[])
   {
	ManosMov pablo = new Handi();
	pablo.hablar();
   }
}

class chef extends Persona {
    String especialidad;
}

class Handi extends Persona implements ManosMov{
    public void moverManos(){
        	System.out.println("Moviendo las manitas");
    }
}

class Bombero extends Persona{
    String fuego;
}

class Estudiante extends Persona{
    String carrera;
}

class Policia extends Persona{
    String pistola;
}


